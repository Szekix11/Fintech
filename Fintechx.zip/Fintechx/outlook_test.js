const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({ executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe', headless: false });
  const page = await browser.newPage();
  
  // Bejelentkezés az Outlook.com felületére
  await page.goto('https://login.live.com/login.srf?wa=wsignin1.0&rpsnv=16&ct=1697712273&rver=7.0.6738.0&wp=MBI_SSL&wreply=https%3a%2f%2foutlook.live.com%2fowa%2f%3fcobrandid%3dab0455a0-8d03-46b9-b18b-df2f57b9e44c%26nlp%3d1%26deeplink%3dowa%252f%26RpsCsrfState%3d2b79e1df-060a-4efd-66f3-d8efcbbedb81&id=292841&aadredir=1&CBCXT=out&lw=1&fl=dob%2cflname%2cwld&cobrandid=ab0455a0-8d03-46b9-b18b-df2f57b9e44c');
  await page.waitForSelector('input[name="loginfmt"]');
  await page.type('input[type="email"]', 'szana15@outlook.com');
  await page.click('input[type="submit"]');
  await page.waitForTimeout(7000); // Várakozás betöltésre

  // Bejelentkezés jelszóval (Azonosítókat be kell állítani a fájlban!)
  await page.waitForSelector('input[type="password"]');
  await page.type('input[type="password"]', 'Bogika99');
  await page.click('input[type="submit"]');
  await page.waitForTimeout(5000); // Várakozás betöltésre

  // Email küldése
  await page.goto('https://outlook.live.com/mail/compose');
  await page.waitForTimeout(70000); // Várakozás betöltésre
  await page.type('div[aria-label="Címzett"]', 'szekix16@gmail.com');
  await page.type('input[aria-label="Adja meg a tárgyat"]', 'Random Subject');
  await page.type('div[aria-label="Üzenet szövege, nyomja meg az Alt+F10 gombot a kilépéshez"]', 'Teszt üzenet a Puppeteer segítségével.');


  await page.click('button[aria-label="Küldés"]'); // "Küldés" gombra kattintás
  



  await page.waitForTimeout(5000); // Várakozás elküldésre

  const isRandomSubjectPresent = await page.evaluate(() => {
    const spanElement = document.querySelector('div.IjzWp.XG5Jd.gy2aJ.Ejrkd span[title="Random Subject"]');
    return spanElement && spanElement.innerText.includes('Random Subject');
  });
  
  if (isRandomSubjectPresent) {
    console.log('Az "Elküldött elemek" mappában megtalálható az e-mail "Random Subject" címmel.');
  } else {
    console.log('Az "Elküldött elemek" mappában nem található olyan e-mail "Random Subject" címmel.');
  }
  

  // Email törlése az elküldött mappából
 // Kattintás a "Mappa ürítése" gombra
 await page.waitForTimeout(9000); // Várakozás betöltésre
await page.click('button[aria-label="Mappa ürítése"]');
// Várakozás a törlés befejezésére
await page.waitForTimeout(2000);

// Kattintás a "Az összes törlése" gombra
await page.click('button#ok-1');

// Várakozás a párbeszédablak megjelenésére
await page.waitForSelector('div#ModalFocusTrapZone4618');

// Kattintás az "Az összes törlése" gombra a párbeszédablakban
await page.click('button#ok-1.ms-Button--primary.jya0z.root-459 .ms-Button-label#id__541');

// Várakozás a törlés befejezésére
await page.waitForTimeout(5000);


  // Böngésző bezárása
  await browser.close();
})();
