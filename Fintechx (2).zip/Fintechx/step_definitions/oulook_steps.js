const { Given, When, Then } = require('cucumber');
const puppeteer = require('puppeteer');

let browser;
let page;

Given('A böngészőt megnyitom', async () => {
  browser = await puppeteer.launch({ headless: false });
  page = await browser.newPage();
});

When('Az Outlook.com weboldalt megnyitom', async () => {
  await page.goto('https://outlook.com');
});

// További lépések implementálása a .feature fájl alapján...

Then('A böngészőt bezárom', async () => {
  await browser.close();
});
